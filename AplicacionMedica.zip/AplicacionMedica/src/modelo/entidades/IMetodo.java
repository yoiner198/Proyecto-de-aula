package modelo.entidades;

public interface IMetodo {
    public abstract String getDataStringFormat();
}
